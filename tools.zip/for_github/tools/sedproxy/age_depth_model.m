function [depth_sample,depth_interp,age_model,age_true,sed_true,...
    age_model_timepoints,age_true_timepoints] = age_depth_model(time_in,sed_mean,sed_std, varargin)
% Sedimentation rates are based on Blauuw and Christen et al. (2011), and
% follow a gamma distribution. Correlation of accumulation rates between 
% sections is determined by R (bounded between 0 and 1), which follows a
% beta distribution with shape parameters a_w, b_w. Core ages are then "sampled" at
% N (= age_samp) discrete depths, and then a linear model is built to
% estimate ages at all depths. Estimated ages have an uncertainty
% associated with them (age_err, which is assumed to be a bounded Gaussian).
%
% INPUTS:
% time_in [yrs] : times at which to generate sedimentation record
% sed_mean [ yr per cm ] : mean sedimentation rate
% sed_std [ yr per cm ] : standard deviation of sedimentation rate
% (optional) shape parameters for R : should be in a vector [a_w, b_w] (default = [7, 3])
% (optional) delc : separation in cm between depth segments (ie, how often
%           to change the accumulation rate; default = 10 cm)
% (optional) age_samp : number of age samples to take
% 
% OUTPUTS:
% depth_sample : depths at which ages were modeled
% depth_interp : depths for the entire timeseries
% age_model : estimated ages for the entire timeseries
% sedimentation rate : true sedimentation rate for the entire timeseries
% age_model_timespoints : estimated ages at times given in time_in
% age_true_timespoints : true ages at times given in time_in

if isempty(varargin)
    % these parameters assume high memory
    % for low memory, b = 1/25, aw = 2, bw = 28
    a_w = 7; b_w = 3;
    delc = 10; %how often to change the accumulation rate [cm]
        % For a record of 10,000 years and a mean accumulation rate of 50 cm,
        % delc = 10 will generate ~19 accumulation rates. Lower delc will generate
        % a smoother sedimentation record, higher delc will generate a jumpier
        % sedimentation record
    age_samp = 10; % how many age samples to take
elseif length(varargin)==1
    a_w = varargin{1}(1); b_w = varargin{1}(2);
    delc = 10; age_samp = 10;
elseif length(varargin)==2
    a_w = varargin{1}(1); b_w = varargin{1}(2);
    delc = varargin{2}; age_samp = 10;
elseif length(varargin)==3
    a_w = varargin{1}(1); b_w = varargin{1}(2);
    delc = varargin{2}; age_samp = varargin{3};
end

time_in = time_in(:);
max_time = max(abs(time_in));
x = sed_mean; y = sed_std;  % now in yrs per cm

disp(['Mean sedimentation rate: ' num2str(x) ' cm / yr'])
disp(['Std of sedimentation rate: ' num2str(y) ' cm / yr'])

% Build gamma distribution (in Bacon, this is the prior)
% Parameters for sediment accumulation
a = x^2./y^2; % Mean value is a*b (yr per cm)
b = y.^2./x; % Variance is a*b^2

% beta distribution - the correlation of accumulation rates of 
% any two sections of the core separated by ds cm
a_w = 7;
b_w = 3;
ds = 1; %separation in cm

w = 0.01:0.01:1; % possible memories
fR = betapdf(w.^(ds/delc),a_w,b_w);
fR = fR/sum(fR);
fw = ds*w.^(ds/delc-1)/delc;
fw = fw./sum(fw);
f_w = fR.*fw;
f_w = f_w./sum(f_w);

% build distribution
w_samp = randsample(w, round(max_time), true, f_w);

% Parameters for age-depth model
age_err = 40; % yrs - what is the error in each radiocarbon date? This can be changed
d_depth = 1;

% Produce sedimentation record
dt = 1;
yr = 1:dt:max_time;
alpha = gamrnd(a,b,round(max_time),1);
sed_rate = zeros(1,round(max_time));
sed_rate(1) = a*b; % first timestep just uses the a*b
total_depth = sed_rate;

% annual sedimentation rate (units are yr per cm)
for i = 2:round(max_time) 
  ind = floor((sum(1./sed_rate(1:i-1)))./delc)+1; % depth sedment at yr i
  sed_rate(i) = w_samp(ind)*sed_rate(i-1) + (1-w_samp(ind))*alpha(ind); % sedimentation rate at year i
end

sed_rate_yr = 1./sed_rate; % units of cm per yr

% get total depth
for i = 2:round(max_time)
  total_depth(i) = sum(sed_rate_yr(2:i))*dt; 
end
total_depth(1) = 0; total_depth = fliplr(total_depth);

seg = max(total_depth):-max(total_depth)/age_samp:0;
idx(1) = 1;
  
age = yr - max(yr);

for i = 2:length(seg)
    idx(i) = find(abs(total_depth - seg(i))==min(abs(total_depth - seg(i))));
end

ct = 1;
err1 = age(1);
time_err = zeros(1,length(idx)); 

% Add dating uncertainty, normally distributed (bounded)
% This  Blauuw and Christen et al. (2011) for details on how to add
% radiocarbon dating error (not included here)
for i = idx
  if i==1
      time_err(1) = age(i) + age_err*randn();
      err1 = time_err(ct) + 1; ct = ct+1;
  elseif(i<length(total_depth)) 
      flg = 1;
      while flg
          err = age(i) + age_err*randn();
          if err>err1 && err<0
              time_err(ct) = err; err1 = time_err(ct) + 1; ct = ct+1;
              flg = 0;
          end
      end
  else
      time_err(ct) = age(i);
  end
end

% This predicts ages for every depth measurement
depth_interp = max(total_depth):-d_depth:0; % depths across the core
depth_sample = total_depth(idx); % sampled depths
age_model = interp1(depth_sample,time_err,depth_interp); % "predicted" ages at all depths
age_true = interp1(total_depth,age,depth_interp); % true ages at all depths
sed_true = interp1(total_depth,sed_rate,depth_interp); % true sedimentation rate at all depths

depth_model_timepoints = interp1(age_model,depth_interp,time_in);
depth_true_timepoints = interp1(age_true,depth_interp,time_in);

% ages at timepoints of interest
age_model_timepoints = interp1(depth_interp,age_model,depth_model_timepoints); % predicted ages at depth tiepoints
age_true_timepoints = interp1(depth_interp,age_true,depth_true_timepoints); % true ages at depth tiepoints

end
