%%

clear; close all;

figure('Position',[10 10 1000 400])
N = 10000; dt = 1;
t = -N:dt:0; 
idx = 1:100:N;
timepoints = t(idx);
sed_mean = 50; % this is in cm per kyr! need to transform into yr per cm
sed_std = 100;
col = {rgb('dark grey'),rgb('orange')};

[depth_sample,depth_interp,age_model,age_true,sed_true,~,~] = age_depth_model(timepoints,1/(sed_mean/1000),1/(sed_std/1000));

depth_sample = depth_sample/100; % now in m
depth_interp = depth_interp/100; % now in m

subplot(1,2,1)
plot(-age_true,depth_interp,'linewidth',2,'color',col{1}); hold on;
plot(-age_model,depth_interp,'linewidth',2,'color',col{2})
%xline(depth_interp,'-','color',[1 1 1 0.3])
scatter(-[interp1(depth_interp,age_true,depth_sample) age_true(end)],[depth_sample depth_sample(end)],100,'*','markeredgecolor',col{2})
h = gca; h.YDir = 'Reverse'; set(gca,'fontsize',14)
h.XDir = 'Reverse';

ylabel('depth (m)'); xlabel('age (yr)'); ylim([0 max(depth_interp)])
xlim(-[max(t) min(t)])
legend('true age \phi','modeled age \phi','sampled ages','location','northwest'); grid on;

subplot(1,2,2)
histogram(age_model-age_true,'facecolor','k','normalization','probability'); set(gca,'fontsize',14)

%F = gca; G = F.YAxis.Limits; G(2) = G(2)+0.05;

ylim([0 0.3]); xlim([-350 350]); ylabel('probability')

hold on;
ar1 = annotation('arrow');
ar1.LineWidth = 2;
ar1.Position = [0.745 0.88 0.08 0];
text(-270,0.27,'\it age model is older','fontsize',14)
text(10,0.27,'\it age model is younger','fontsize',14)
grid on;

ar2 = annotation('arrow');
ar2.LineWidth = 2;
ar2.Position = [0.73 0.88 -0.08 0];
xlabel('\phi - \phi (yr)')

%% try a bunch

clear; close all;

figure('Position',[10 10 1000 400])

nruns = 1000;

AGE_TRUE = cell(1,nruns);
AGE_MODEL = cell(1,nruns);
DEPTH_INTERP = cell(1,nruns);

N = 10000; dt = 1;
t = -N:dt:0;
idx = 1:100:N;
timepoints = t(idx);
sed_mean = 50; % this is in cm per kyr! need to transform into yr per cm
sed_std = 100;

for nn = 1:nruns

    %sed_mean = 50+5*randn(1); 
    %if sed_mean<20 | sed_mean>100
    %    sed_mean = 50;
    %end
    %if sed_std>150 | sed_std <50
    %    sed_std = 100;
    %end

    [depth_sample,depth_interp,age_model,age_true,sed_true,~,~] = age_depth_model(timepoints,1/(sed_mean/1000),1/(sed_std/1000));

    depth_sample = depth_sample/100; % now in m
    depth_interp = depth_interp/100; % now in m

    AGE_TRUE{nn} = age_true;
    AGE_MODEL{nn} = age_model;
    DEPTH_INTERP{nn} = depth_interp;

end

%%

subplot(1,2,1)
for i = 1:10 %nruns
    plot(AGE_MODEL{i}-AGE_TRUE{i},DEPTH_INTERP{i},'linewidth',1,...
        'color',[1 1 1 0.2]); hold on;
end

%%


X = cell2mat(AGE_MODEL); Y = cell2mat(AGE_TRUE);
edges = -400:25:400;
histogram(X-Y,edges,'facecolor','k','normalization','probability'); set(gca,'fontsize',14)
xlim([-350 350]); ylabel('probability')

